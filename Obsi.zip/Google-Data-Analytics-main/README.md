# Google-Data-Analytics Certification

Notes for the course on Data Analytics by Google in Coursera. Course [link](https://www.coursera.org/professional-certificates/google-data-analytics?utm_source=google&utm_medium=institutions&utm_campaign=gwgsite-paid-essence-in-dr-q42021-sem-bkws-exa-txt-course-1-analytics-certificate-data_analytics). 
