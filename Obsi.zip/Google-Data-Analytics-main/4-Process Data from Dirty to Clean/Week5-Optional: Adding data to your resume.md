Nothing specific. Enroll in, or Preview the course and visit [here](https://www.coursera.org/learn/process-data/home/week/5) for tips to build an effective resume for a data analyst position.

---

[Glossary](https://docs.google.com/document/d/1M5ECYjyOHafeVj-ryAE2rDXA8iYPSlxCyvPHPIlGdqk/template/preview)

---
